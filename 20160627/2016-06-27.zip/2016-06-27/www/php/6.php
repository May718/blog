<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>无标题文档</title>
<script>
</script>
</head>

<body>
<?php
function show($a,$b){
	return $a+$b;
}
$result = show(12,3);
echo $result;
?>
</body>
</html>












