-- phpMyAdmin SQL Dump
-- version 2.11.2.1
-- http://www.phpmyadmin.net
--
-- 主机: localhost
-- 生成日期: 2016 年 06 月 27 日 04:06
-- 服务器版本: 5.0.45
-- PHP 版本: 5.2.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- 数据库: `20160627`
--

-- --------------------------------------------------------

--
-- 表的结构 `flow_tab`
--

CREATE TABLE `flow_tab` (
  `img_url` varchar(100) collate utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- 导出表中的数据 `flow_tab`
--

INSERT INTO `flow_tab` (`img_url`) VALUES
('00e93901213fb80e1143401236d12f2eb8389460.jpg'),
('00e93901213fb80e2d5f7c2c36d12f2eb83894ba.jpg'),
('00e93901213fb80e3098672036d12f2eb83894ff.jpg'),
('00e93901213fb80e6677355436d12f2eb838948a.jpg'),
('00e93901213fb80e6688355436d12f2eb83894d3.jpg'),
('00e93901213fb80e89fed83736d12f2eb9389427.jpg'),
('00e93901213fb80eec76b34c36d12f2eb8389482(2).jpg'),
('00e93901213fb80eecacb34c36d12f2eb9389428(3).jpg'),
('0b46f21fbe096b63659cd8850c338744eaf8ac5a.jpg'),
('0b46f21fbe096b63a9508ccb0c338744eaf8ace4(1).jpg'),
('0b55b319ebc4b745312d09f6cffc1e178b821590.jpg'),
('0b55b319ebc4b74532600ecbcffc1e178b821572.jpg'),
('0b55b319ebc4b745433e7ff5cffc1e178b8215ae.jpg'),
('0b55b319ebc4b74555e9658dcffc1e178a82152f(3).jpg'),
('0b55b319ebc4b745e991d1e8cffc1e178b8215c2.jpg'),
('0b7b02087bf40ad15fb21578572c11dfa8ecced3(3).jpg'),
('0bd162d9f2d3572c2fce40478a13632762d0c379.jpg'),
('0d338744ebf81a4c09ad2d3fd72a6059242da6ad.jpg'),
('0d338744ebf81a4c34113e52d72a6059252da60e(1).jpg'),
('0d338744ebf81a4c34113e52d72a6059252da60e(2).jpg'),
('0d338744ebf81a4c34113e52d72a6059252da60e(3).jpg'),
('0d338744ebf81a4c34643e52d72a6059242da6d3(1).jpg'),
('0d338744ebf81a4c34643e52d72a6059242da6d3(3).jpg'),
('0d338744ebf81a4c586f9a27d72a6059242da6fa.jpg'),
('0d338744ebf81a4c6e0fd40ed72a6059252da633.jpg'),
('0d338744ebf81a4c74c5fe1dd72a6059242da66a.jpg'),
('0d338744ebf81a4c9288502dd72a6059242da698.jpg'),
('0dd7912397dda1447861ce6cb2b7d0a20df48680.jpg'),
('0df3d7ca7bcb0a46ae9e59a26b63f6246a60afe9(2).jpg'),
('0df3d7ca7bcb0a46ae9e59a26b63f6246a60afe9.jpg'),
('0df3d7ca7bcb0a46bdbd4acf6b63f6246a60afad.jpg'),
('0df431adcbef7609a181267f2edda3cc7dd99e4c.jpg'),
('0df431adcbef7609a280277f2edda3cc7dd99e43.jpg'),
('0e2442a7d933c89512ee8aafd11373f083020055.jpg'),
('0e2442a7d933c89566389e8cd11373f083020086.jpg'),
('0e2442a7d933c8957f2991aed11373f08302008b.jpg'),
('0e2442a7d933c8958ea5269bd11373f083020072.jpg'),
('0e2442a7d933c895d2de4ae0d11373f08302008c(2).jpg'),
('0e2442a7d933c895f772698bd11373f082020035.jpg'),
('0eb30f2442a7d93365deeda6ad4bd11372f001f4.jpg'),
('0eb30f2442a7d9336794ebf0ad4bd11373f00170.jpg'),
('0eb30f2442a7d933cafe36e8ad4bd11372f001d2(3).jpg'),
('0eb30f2442a7d933eeee1283ad4bd11372f001ff.jpg'),
('0ff41bd5ad6eddc447ea401139dbb6fd536633ce.jpg'),
('0ff41bd5ad6eddc45e9e491439dbb6fd536633e7.jpg'),
('0ff41bd5ad6eddc4a1d5666039dbb6fd5266337f(3).jpg'),
('0ff41bd5ad6eddc4a1e2666039dbb6fd52663320(2).jpg'),
('0ff41bd5ad6eddc4b320747839dbb6fd5366336a.jpg'),
('0ff41bd5ad6eddc4c78cc07439dbb6fd536633d1.jpg'),
('1ad5ad6eddc451da7ac3e46ab6fd5266d016327e.jpg'),
('1ad5ad6eddc451da9673f81cb6fd5266d11632bb.jpg'),
('1ad5ad6eddc451daccdcb20bb6fd5266d0163223.jpg'),
('1ad5ad6eddc451dacefcb06ab6fd5266d016322c.jpg'),
('1b4c510fd9f9d72a084ec286d42a2834349bbb07(2).jpg'),
('1b4c510fd9f9d72a3b27d1ebd42a2834359bbb81.jpg'),
('1b4c510fd9f9d72a5bcb31d8d42a2834359bbb43.jpg'),
('1b4c510fd9f9d72a7e00149ed42a2834359bbbc8.jpg'),
('1b4c510fd9f9d72aa4a5aefdd42a2834359bbb09.jpg'),
('1b4c510fd9f9d72ad82ab2c3d42a2834359bbba6.jpg'),
('1b4c510fd9f9d72adcbdb695d42a2834359bbb59.jpg'),
('1c950a7b02087bf41eea6d2ef2d3572c10dfcff6.jpg'),
('1c950a7b02087bf47059cb3df2d3572c10dfcfa9.jpg'),
('1c950a7b02087bf498f8f364f2d3572c11dfcf23.jpg'),
('1e30e924b899a901a6d85dc11d950a7b0308f55c.jpg'),
('1e30e924b899a901de36e5d61d950a7b0308f5cb.jpg'),
('t02081619dff138cc55.jpg');
