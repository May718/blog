<?php
$username = $_GET["username"];
$password = $_GET["password"];
echo "用户名是：".$username."，密码是：".$password;
?>