<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>无标题文档</title>
</head>

<body>
<?php
	$a = 12;
	$b = 5;
	echo $a+$b;
?>
</body>
</html>












