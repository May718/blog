<?php
$username = $_POST["username"];
$password = $_POST["password"];
echo "用户名是：".$username."，密码是：".$password;
?>