var str = 'fdjskl43 hk32jh hkfd78429 hk232';
console.log(str.match(/\d+/g));