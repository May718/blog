var str = "How old are you?";
//alert(str);
//document.write(str);
console.log(str);