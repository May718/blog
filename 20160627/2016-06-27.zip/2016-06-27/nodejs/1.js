var str = "How old are you?";
console.log(str);