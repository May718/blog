var arr = [12,5,3,4,8,6,7];
arr.sort(function(num1,num2){
	return num1-num2;
});
console.log(arr);